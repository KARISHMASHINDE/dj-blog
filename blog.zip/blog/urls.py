from django.urls import path
from . import views 

# /blog
urlpatterns = [
  path('',views.home),
  path('about/',views.about),
]