from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
all_posts = [

    {
        'author':'James',
        'title':'How Learn Django Quickly',
        'content':'In this post i will teach you How Learn Django Quickly',
        'date_posted':'Dec 24,2019 10:00 AM'

    },
    {
        'author':'Tom',
        'title':'Python JSON',
        'content':'How to deal with Python JSON',
        'date_posted':'Dec 23,2019 1:00 PM'

    }
]


def home(request):
   data = {
       'posts':all_posts
   }
   return render(request,'home.html',data)

def about(request):
    return render(request,'about.html')
    
